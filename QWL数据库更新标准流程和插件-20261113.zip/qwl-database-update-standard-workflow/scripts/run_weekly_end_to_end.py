#!/usr/bin/env python3
"""One manual QWL launch: checkpointed week, independent acceptance, PIT and cleanup."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import signal
import fcntl
from datetime import datetime, time as time_of_day, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

PROJECT = Path("/Users/bytedance/Documents/ChatGPT/量化交易")
DATABASE = Path("/Users/bytedance/Desktop/60只股票全量历史数据_20260816")
RUNTIME = Path("/Users/bytedance/Desktop/bytedance/扣子/Trae对话/量化炒股Plugin-自选股/quant-watchlist-plugin")
TZ = ZoneInfo("Asia/Shanghai")
INSTALLED_PLUGIN = None

class TransientProcessFailure(RuntimeError):
    pass


def process_failure(command, stdout, stderr):
    detail = stdout[-1500:] + stderr[-1500:]
    known = ('429 Too Many Requests', 'stream disconnected', 'response.failed',
             'StreamClosed', 'Connection reset by peer')
    if any(Path(part).name == 'weekly_cli.py' for part in command) and any(token in detail for token in known):
        return TransientProcessFailure('TRANSIENT_CLI_TRANSPORT: ' + detail)
    return RuntimeError('COMMAND_BLOCKED: ' + detail)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class CommandOutputError(RuntimeError):
    """Exited command has no trustworthy structured response"""
    pass


def invoke(command: list[str], *, timeout: int = 43200, expect_json: bool = True) -> dict:
    print(json.dumps({"phase":"COMMAND_START","command":Path(command[2]).name if len(command)>2 else command[0]}),
          flush=True)
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE':'1',
        'PYTHONPATH':os.pathsep.join(map(str,(INSTALLED_PLUGIN or Path(command[2]).resolve().parents[1],RUNTIME/'src',PROJECT)))}
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        cwd=str(PROJECT), env=env, start_new_session=True)
    begun = time.monotonic()
    shown = 0
    try:
        while True:
            remaining = timeout - (time.monotonic() - begun)
            if remaining <= 0:
                raise TimeoutError('COMMAND_TIMEOUT')
            try:
                stdout, stderr = process.communicate(timeout=min(15,remaining))
                if stderr[shown:]:print(stderr[shown:],file=sys.stderr,end='',flush=True)
                break
            except subprocess.TimeoutExpired as exc:
                partial = exc.stderr or ''
                if isinstance(partial, bytes):partial=partial.decode(errors='replace')
                if partial[shown:]:print(partial[shown:],file=sys.stderr,end='',flush=True)
                shown=len(partial)
                print(json.dumps({'phase':'COMMAND_RUNNING','elapsed_seconds':int(time.monotonic()-begun)}),flush=True)
    except BaseException:
        if process.poll() is None:
            os.killpg(process.pid,signal.SIGKILL)
        process.wait()
        raise
    if process.returncode:
        raise process_failure(command,stdout,stderr)
    if expect_json:
        try:
            result = json.loads(stdout)
        except json.JSONDecodeError as exc:
            raise CommandOutputError(f"UNPARSEABLE_COMMAND_OUTPUT: {command[1]}: {stdout[-1000:]}") from exc
    else:
        result = {"stdout": stdout[-1500:]}
    return result


def evidence_child(root: Path, name: str) -> Path:
    path = root / name
    if path.exists():
        index = 2
        while path.with_name(name + f'-attempt-{index}').exists():
            index += 1
        path = path.with_name(name + f'-attempt-{index}')
    return path


def wait_for_retry(value: dict, as_of: str, deadline: datetime) -> bool:
    stamp = value.get("next_retry_at")
    if not stamp:
        raise RuntimeError("WAITING_WITHOUT_NEXT_RETRY_AT")
    wake = datetime.fromisoformat(stamp)
    if wake.tzinfo is None:
        raise RuntimeError("RETRY_TIME_LACKS_TIMEZONE")
    while datetime.now(TZ) < wake:
        current = datetime.now(TZ)
        if current >= deadline or current.isoweekday() == 1:
            return False
        remaining = (wake-current).total_seconds()
        print(json.dumps({"phase":"WAITING_RETRY","as_of":as_of,
                          "next_retry_at":stamp,"seconds_remaining":int(remaining)}),
              flush=True)
        time.sleep(max(1,min(60,remaining,(deadline-current).total_seconds())))
    return True


def current_job(as_of: str) -> Path:
    key = hashlib.sha256(str(DATABASE.resolve()).encode()).hexdigest()[:16]
    return RUNTIME / "state/weekly_jobs" / key / as_of / "job.json"


def weekly_until_terminal(python: Path, plugin: Path, as_of: str, deadline: datetime) -> dict:
    cli = plugin / "scripts/weekly_cli.py"
    health = invoke([str(python),"-B",str(cli),"health"], timeout=120)
    if not health.get("ok") or not health.get("frozen_sources",{}).get("ok"):
        raise RuntimeError("FROZEN_PLUGIN_HEALTH_FAILED")
    recoveries = 0
    while datetime.now(TZ) < deadline:
        try:
            value = invoke([str(python),'-B',str(cli),'status','--as-of',as_of])
        except TransientProcessFailure:
            recoveries += 1
            if recoveries > 6:raise
            print(json.dumps({'phase':'RECOVER_TRANSPORT','attempt':recoveries}),flush=True)
            time.sleep(min(60,2**recoveries))
            continue
        if value.get('status') == 'COMPLETE' and value.get('complete') is True:
            return value
        if value.get('status') == 'COMPLETE':
            raise RuntimeError('COMPLETE_STATUS_WITHOUT_COMPLETE_FLAG')
        if str(value.get('status','')).startswith('BLOCKED'):
            return value
        try:
            value = invoke([str(python),"-B",str(cli),"update","--as-of",as_of])
        except TransientProcessFailure:
            recoveries += 1
            if recoveries > 6:raise
            print(json.dumps({'phase':'RECOVER_TRANSPORT','attempt':recoveries}),flush=True)
            time.sleep(min(60,2**recoveries))
            continue  # Always inspect the same checkpoint before any re-run
        print(json.dumps({"phase":"WEEKLY_UPDATE","status":value.get("status"),
                          "attempt":value.get("attempt"),"gaps":len(value.get("gaps",[])),
                          "next_retry_at":value.get("next_retry_at")},ensure_ascii=False),flush=True)
        if value.get("status") == "COMPLETE" and value.get("complete") is True:
            return value
        if value.get("status") == "COMPLETE":
            raise RuntimeError("COMPLETE_STATUS_WITHOUT_COMPLETE_FLAG")
        if value.get("status") in {"WAITING_RETRY","WAITING_SOURCE"}:
            if not wait_for_retry(value,as_of,deadline):
                return value
            continue
        if value.get("status") in {"RUNNING","PUBLISHING"}:
            time.sleep(30)
            continue
        return value
    return {"status":"WAITING_WINDOW_END","complete":False}


def accepted_formal(plugin: Path, as_of: str, job: Path, run: Path) -> dict:
    sys.path.insert(0,str(plugin))
    sys.path.insert(0,str(PROJECT))
    from scripts.weekly_acceptance import materialize
    from weekly_formal_acceptance import verify
    with tempfile.TemporaryDirectory(prefix="qwl-independent-formal-") as directory:
        view = Path(directory)
        materialize(DATABASE,None,view)
        return verify(view=view,runtime=RUNTIME,as_of=as_of,job_path=job,
                      database=DATABASE,run=run)


def require_release(path: Path, as_of: str) -> str:
    """A file existing alone is not proof of an accepted, complete release"""
    if not (path / 'release.json').is_file():raise RuntimeError('RELEASE_MISSING: '+str(path))
    spec=json.loads((path/'release.json').read_text());commit=json.loads((path/'COMMIT.json').read_text())
    release_sha=sha(path/'release.json')
    registry=json.loads((PROJECT/'weekly_plugin_runner/registry.json').read_text())
    models=registry['models'];inputs={p for model in models for p in model['inputs']}
    if (spec.get('week_end')!=as_of or spec.get('latest_trade_date')!=as_of
            or len(models)!=12 or len({m['symbol'] for m in models})!=12
            or set(spec.get('scope_symbols',[]))!={m['symbol'] for m in models}
            or spec.get('scope_model_count')!=12 or spec.get('scope_consumption_input_count')!=len(inputs)
            or not inputs<=set(spec.get('logical_files',{})) or spec.get('quarantine_members_included')!=0
            or commit.get('status')!='ACCEPTED_MANUAL_RELEASE' or commit.get('private_candidate') is not False
            or commit.get('release_sha256')!=release_sha):
        raise RuntimeError('RELEASE_CONTRACT_FAILED: '+str(path))
    manifest=path/'MANIFEST_SHA256_SIZE.txt'
    if sha(manifest)!=commit.get('manifest_sha256'):raise RuntimeError('RELEASE_MANIFEST_SHA_DRIFT')
    seen=set()
    for line in manifest.read_text().splitlines():
        expected,size,name=line.split('  ',2)
        prefix='state/pit_gateway/releases/'+path.name+'/'
        if name.startswith('state/') and not name.startswith(prefix):raise RuntimeError('RELEASE_MANIFEST_SCOPE')
        member=Path(name[len(prefix):] if name.startswith(prefix) else name)
        file=path/member
        if (member.is_absolute() or '..' in member.parts or name in seen or file.is_symlink()
                or not file.resolve().is_relative_to(path.resolve())
                or not file.is_file() or file.stat().st_size!=int(size) or sha(file)!=expected):
            raise RuntimeError('RELEASE_MEMBER_SHA_DRIFT: '+name)
        seen.add(name)
    entry=json.loads((path/'ENTRYPOINT.json').read_text())
    if entry.get('release_sha256')!=release_sha:raise RuntimeError('RELEASE_ENTRYPOINT_SHA_DRIFT')
    return release_sha


def publish_or_recover(command, release, as_of, weekly_run_id):
    """Recover only a fully committed artifact; never reinterpret safety failures"""
    try:
        return invoke(command)
    except (CommandOutputError,TransientProcessFailure):
        if not release.exists():raise
        fingerprint=require_release(release,as_of)
        descriptor=json.loads((release/'release.json').read_text())
        if descriptor.get('weekly_run_id')!=weekly_run_id:raise RuntimeError('RECOVERY_WEEKLY_RUN_DRIFT')
        return {'status':'RECOVERED_COMMITTED_ALL12_RELEASE','release_sha256':fingerprint}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--as-of",required=True)
    parser.add_argument("--installed-plugin",required=True)
    parser.add_argument("--previous-release",required=True)
    parser.add_argument("--previous-release-sha",required=True)
    parser.add_argument("--evidence",required=True)
    parser.add_argument("--authorization",required=True)
    args = parser.parse_args()
    if args.authorization != "PUBLISH_CURRENT_WEEK":
        raise RuntimeError("CURRENT_WEEK_AUTHORIZATION_REQUIRED")
    as_of = args.as_of
    target = datetime.fromisoformat(as_of)
    if target.weekday() != 4:
        raise RuntimeError("TARGET_MUST_BE_FRIDAY")
    evidence = Path(args.evidence).resolve()
    if evidence == PROJECT / "weekly_evidence" or not evidence.is_relative_to(PROJECT / "weekly_evidence"):
        raise RuntimeError("EVIDENCE_OUTSIDE_PROJECT")
    evidence.mkdir(parents=True,exist_ok=True)
    plugin = Path(args.installed_plugin).resolve()
    global INSTALLED_PLUGIN
    INSTALLED_PLUGIN = plugin
    binding = {'as_of':as_of,'previous_release':str(Path(args.previous_release).resolve()),
        'previous_release_sha256':args.previous_release_sha,'installed_plugin':str(plugin)}
    identity = evidence/'PIPELINE_BINDING.json'
    if identity.exists():
        if json.loads(identity.read_text()) != binding:
            raise RuntimeError('PIPELINE_RESUME_BINDING_DRIFT')
    else:
        with identity.open('x') as handle:
            json.dump(binding,handle,ensure_ascii=False,indent=2)
    if sha(Path(args.previous_release)/'release.json') != args.previous_release_sha:
        raise RuntimeError('PARENT_SHA_DRIFT')
    # A separate downstream journal never resets the frozen weekly job
    lock = (evidence/'pipeline.lock').open('a+')
    fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
    def stage(name, **extra):
        record = {'phase':name, 'as_of':as_of, **extra}
        temporary = evidence/'pipeline.json.tmp'
        with temporary.open('w') as handle:
            json.dump(record,handle,ensure_ascii=False,indent=2)
            handle.flush();os.fsync(handle.fileno())
        os.replace(temporary,evidence/'pipeline.json')
        print(json.dumps(record,ensure_ascii=False),flush=True)
    stage('DATABASE_CHECKPOINT')
    python = RUNTIME / ".venv/bin/python"
    deadline = datetime.combine(target.date() + timedelta(days=2),
                                time_of_day(23,59,59),tzinfo=TZ)
    result = weekly_until_terminal(python,plugin,as_of,deadline)
    if result.get("status") != "COMPLETE" or result.get("complete") is not True:
        print(json.dumps({"status":"NOT_COMPLETE","weekly":result},ensure_ascii=False),flush=True)
        return 2
    job = current_job(as_of)
    state = json.loads(job.read_text())
    publication = state.get("publication",{})
    if publication.get("status") != "PUBLISHED" or not publication.get("run_id"):
        raise RuntimeError("COMPLETE_WITHOUT_PUBLICATION_RUN_ID")
    run = DATABASE / "state/weekly_runs" / publication["run_id"]
    formal = accepted_formal(plugin,as_of,job,run)
    formal_path = evidence/'FORMAL_WEEK_ACCEPTANCE.json'
    if formal_path.exists() and json.loads(formal_path.read_text()) != formal:
        formal_path = evidence / ('FORMAL_WEEK_ACCEPTANCE-' + datetime.now(TZ).strftime('%Y%m%dT%H%M%S%f') + '.json')
    if not formal_path.exists():
        with formal_path.open('x') as handle:
            json.dump(formal,handle,ensure_ascii=False,indent=2)
    if formal.get("status") != "FORMAL_WEEK_ACCEPTED":
        print(json.dumps({"status":"PUBLISHED_BUT_NOT_FORMALLY_ACCEPTED","formal":formal},ensure_ascii=False),flush=True)
        return 2
    stage('PIT_PUBLICATION',weekly_run_id=publication['run_id'])
    release = DATABASE / "state/pit_gateway/releases" / f"{as_of}-all12-models-pit-v1"
    if not release.exists():
        publish_or_recover([str(python),"-B",str(Path(__file__).with_name("publish_all12_pit_release.py")),
            "--database",str(DATABASE),"--project",str(PROJECT),
            "--registry",str(PROJECT / "weekly_plugin_runner/registry.json"),
            "--parent-release",args.previous_release,"--parent-release-sha",args.previous_release_sha,
            "--weekly-run-id",publication["run_id"],"--as-of",as_of,
            "--release-id",release.name,"--authorization","PUBLISH_ALL12_PIT_CURRENT_WEEK",
            "--evidence",str(evidence_child(evidence,"all12-publication"))], release, as_of, publication['run_id'])
    release_sha = require_release(release,as_of)
    descriptor = json.loads((release/'release.json').read_text())
    if descriptor.get('weekly_run_id') != publication['run_id']:
        raise RuntimeError('EXISTING_RELEASE_WEEKLY_RUN_DRIFT')
    stage('READINESS',release=str(release),release_sha256=release_sha)
    readiness = invoke([str(python),"-B",str(PROJECT / "weekly_release_readiness_gate.py"),
        "--release-dir",str(release),"--release-sha",release_sha,"--as-of",as_of,
        "--vintage","revised","--output",str(evidence_child(evidence,"readiness"))])
    if readiness.get("status") != "ALL_SELECTED_MODELS_READY":
        raise RuntimeError("ALL12_READINESS_FAILED")
    preflight_dir = evidence_child(evidence,"preflight")
    stage('PUBLIC_PREFLIGHT',release=str(release),release_sha256=release_sha)
    invoke([str(python),"-B","-m","weekly_plugin_runner.cli","preflight",
        "--as-of",as_of,"--vintage","revised","--output",str(preflight_dir),
        "--release-dir",str(release),"--release-sha",release_sha], expect_json=False)
    preflight = json.loads((preflight_dir / "preflight.json").read_text())
    if (not preflight.get("all_models_ready_for_forecast") or len(preflight.get('models',[])) != 12
            or any(row.get('external_input_status') != 'INPUT_DELIVERY_PASS' for row in preflight['models'])
            or preflight.get('release_sha256') != release_sha or preflight.get('as_of') != as_of
            or preflight.get('vintage') != 'revised'):
        raise RuntimeError("ALL12_PUBLIC_PREFLIGHT_FAILED")
    from scripts.weekly_retention import audit as retention_audit
    stage('RETENTION')
    cleaned = retention_audit(job_dir=job.parent,database=DATABASE,run_dir=run,
                              independent_report=formal,apply=True)
    retention_path = evidence_child(evidence,'RETENTION.json')
    with retention_path.open('x') as handle:
        json.dump(cleaned,handle,ensure_ascii=False,indent=2)
    stage('ALL12_WEEKLY_COMPLETE',release=str(release),release_sha256=release_sha)
    print(json.dumps({"status":"ALL12_WEEKLY_COMPLETE","as_of":as_of,
                      "weekly_run_id":publication["run_id"],"formal":formal["status"],
                      "release":str(release),"release_sha256":release_sha,
                      "cleanup_freed_bytes":cleaned["freed_bytes"], "database_complete":True,
                      "pit_release_published":True, "ready_models":12, "public_preflight_passed_models":12,
                      "cleanup_audited":True, "overall_complete":True,
                      "all_domains_complete":publication.get('formal_acceptance',{}).get('all_domains_complete',False)},ensure_ascii=False),flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
