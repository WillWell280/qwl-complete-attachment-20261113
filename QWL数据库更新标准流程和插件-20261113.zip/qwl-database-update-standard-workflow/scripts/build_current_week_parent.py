#!/usr/bin/env python3
"""Build one immutable same-week, all-12 PIT parent from the prior approved release

Only formally published members from the accepted weekly run are admitted
Quarantine, working cache, old releases, models, plugins and skills are never
modified or used as release inputs
"""
from __future__ import annotations

import copy
import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import sys
import tempfile
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pandas as pd


DATABASE = Path("/Users/bytedance/Desktop/60只股票全量历史数据_20260816")
PROJECT = Path("/Users/bytedance/Documents/ChatGPT/量化交易")
EVIDENCE = PARENT = RUN = JOB = TARGET = None
PARENT_SHA = RUN_ID = RELEASE_ID = AS_OF = PREFIX_AS_OF = WEEK_START = ""
READER = PROJECT / "qwl_pit_gateway/reader.py"
REGISTRY = PROJECT / "weekly_plugin_runner/registry.json"
TARGET_SYMBOLS = []
SCOPE = "ALL12_PIT_PARENT_FOR_CURRENT_WEEK"
AUTHORIZATION = "PUBLISH_WEEKLY_PIT_CURRENT_WEEK"


class Blocked(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise Blocked(message)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str
    ).encode()


def stable_sha(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def dump_new(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False, default=str)
        handle.write("\n")


def metadata_inventory(root: Path) -> dict[str, tuple[int, int, int]]:
    result: dict[str, tuple[int, int, int]] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        require(not path.is_symlink(), f"DATABASE_SYMLINK_REJECTED: {path}")
        stat = path.stat()
        result[str(path.relative_to(root))] = (stat.st_size, stat.st_mtime_ns, stat.st_mode)
    return result


def inventory_summary(rows: dict[str, tuple[int, int, int]]) -> dict[str, Any]:
    return {
        "file_count": len(rows),
        "metadata_sha256": hashlib.sha256(canonical(sorted(rows.items()))).hexdigest(),
    }


def load_reader():
    spec = importlib.util.spec_from_file_location("qwl_weekly_parent_reader", READER)
    require(spec is not None and spec.loader is not None, "READER_IMPORT_FAILED")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Reader


def frame_bounds(frame: pd.DataFrame) -> tuple[str | None, str | None, int]:
    if frame.empty:
        return None, None, 0
    values = pd.to_datetime(frame["date"] if "date" in frame.columns else frame.index)
    return (
        pd.Timestamp(values.min()).date().isoformat(),
        pd.Timestamp(values.max()).date().isoformat(),
        int(len(frame)),
    )


def logical_for_member(relative: str) -> str:
    prefix = "state/published_versions/"
    if relative.startswith(prefix):
        return "/".join(relative[len(prefix):].split("/")[:-1])
    return relative


def selected_models() -> tuple[list[dict], list[str]]:
    registry = load(REGISTRY)
    models = registry.get("models")
    require(isinstance(models, list) and len(models) == 12, "REGISTRY_MUST_HAVE_12_MODELS")
    selected = models
    require(len(selected) == 12 and {model.get("symbol") for model in selected} == set(TARGET_SYMBOLS),
            "ALL12_PARENT_MODEL_SELECTION_MISMATCH")
    inputs = sorted({relative for model in selected for relative in model.get("inputs", [])})
    require(inputs, "EMPTY_SCOPED_INPUT_CLOSURE")
    return selected, inputs


def validate_weekly() -> tuple[dict, dict, dict]:
    publication = load(RUN / "publication.json")
    catalog = load(RUN / "incremental_catalog.json")
    job = load(JOB)
    require(job.get("status") == "COMPLETE", "WEEKLY_JOB_NOT_COMPLETE")
    require(not job.get("gaps"), "WEEKLY_JOB_HAS_GAPS")
    require(bool(job.get("tasks", {})), "WEEKLY_TASKS_MISSING")
    require(all(item.get("ok") is True for item in job["tasks"].values()), "WEEKLY_TASK_FAILURE")
    require(publication.get("status") == "PUBLISHED", "WEEKLY_RUN_NOT_PUBLISHED")
    require(publication.get("week_start") == WEEK_START, "WEEK_START_MISMATCH")
    require(publication.get("week_end") == AS_OF, "WEEK_END_MISMATCH")
    require(publication.get("formal_acceptance", {}).get("passed") is True, "FORMAL_ACCEPTANCE_FAILED")
    require(publication.get("formal_acceptance", {}).get("issues") == [], "FORMAL_ACCEPTANCE_HAS_ISSUES")
    for key in (
        "formal_existing_files_rewritten",
        "historical_revisions_published",
        "historical_backfills_published",
    ):
        require(publication.get(key) == 0, f"NONZERO_{key.upper()}")
    require(catalog.get("run_id") == RUN_ID, "CATALOG_RUN_MISMATCH")
    require(catalog.get("base_manifest_sha256") == sha(DATABASE / "MANIFEST_SHA256_SIZE.txt"), "BASE_MANIFEST_DRIFT")
    return publication, catalog, job


def build() -> dict[str, Any]:
    require(EVIDENCE.is_dir(), "EVIDENCE_DIRECTORY_MISSING")
    require(not TARGET.exists(), "TARGET_RELEASE_ALREADY_EXISTS")
    require(sha(PARENT / "release.json") == PARENT_SHA, "PARENT_RELEASE_SHA_DRIFT")
    publication, catalog, job = validate_weekly()
    selected, inputs = selected_models()
    Reader = load_reader()
    before = metadata_inventory(DATABASE)
    before_summary = inventory_summary(before)

    with Reader(DATABASE, PARENT, PARENT_SHA) as parent_reader:
        parent_spec = copy.deepcopy(parent_reader.spec)
    require(parent_spec.get("week_end") == PREFIX_AS_OF
            and parent_spec.get("latest_trade_date") == PREFIX_AS_OF,
            "PARENT_WEEK_MISMATCH")
    require(parent_spec.get("reader_sha256") == sha(READER), "PARENT_READER_SHA_DRIFT")
    for relative in inputs:
        require(relative in parent_spec.get("logical_files", []), f"INPUT_NOT_AUTHORIZED: {relative}")
        require(relative in parent_spec.get("base_files", {}), f"BASE_INPUT_NOT_PINNED: {relative}")

    prefixes = tuple(f"state/published_versions/{relative}/" for relative in inputs)
    current: dict[str, str] = {}
    for entry in catalog.get("entries", []):
        relative = entry.get("relative")
        if not isinstance(relative, str) or not relative.startswith(prefixes):
            continue
        path = DATABASE / relative
        require(path.is_file(), f"CURRENT_MEMBER_MISSING: {relative}")
        require(path.stat().st_size == entry.get("bytes"), f"CURRENT_MEMBER_SIZE_DRIFT: {relative}")
        require(sha(path) == entry.get("sha256"), f"CURRENT_MEMBER_SHA_DRIFT: {relative}")
        current[relative] = entry["sha256"]
    require(current, "NO_CURRENT_SCOPED_MEMBERS")
    raw_inputs = sorted(relative for relative in inputs if relative.endswith("_raw.parquet"))
    missing_raw = [
        relative for relative in raw_inputs
        if not any(member.startswith(f"state/published_versions/{relative}/") for member in current)
    ]
    require(not missing_raw, "SCOPED_RAW_INPUTS_ABSENT_FROM_WEEKLY_RUN: " + ",".join(missing_raw))

    base_files = copy.deepcopy(parent_spec["base_files"])
    added_members: list[str] = []
    for relative, expected in sorted(current.items()):
        previous = base_files.get(relative)
        require(previous in (None, expected), f"PARENT_MEMBER_HASH_CONFLICT: {relative}")
        if previous is None:
            base_files[relative] = expected
            added_members.append(relative)
    require(added_members, "NO_NEW_SCOPED_MEMBERS")

    candidate = EVIDENCE / "private-release"
    require(not candidate.exists(), "PRIVATE_CANDIDATE_ALREADY_EXISTS")
    candidate.mkdir()
    shutil.copy2(PARENT / "operations.json", candidate / "operations.json")
    release_files = {"operations.json": sha(candidate / "operations.json")}

    spec = copy.deepcopy(parent_spec)
    for key in (
        "parent_prefix_comparison_sha256",
        "parent_prefix_identical_through",
        "parent_prefix_proof_file",
        "pit_diagnostics_file",
        "target_input_diagnostics_file",
        "target_input_diagnostics_sha256",
        "audit_metadata_extension",
        "supersedes_release_id",
        "supersession_reason",
    ):
        spec.pop(key, None)
    known = copy.deepcopy(parent_spec.get("known_exceptions", {}))
    acceptance = publication["formal_acceptance"]
    week_key = f"weekly_{AS_OF.replace('-', '')}"
    known.update(
        {
            "release_scope": SCOPE,
            f"{week_key}_history_conflict_count": len(acceptance.get("historical_conflicts", [])),
            f"{week_key}_historical_basis_unverified_count": len(acceptance.get("historical_basis_unverified", [])),
            f"{week_key}_history_conflicts": acceptance.get("historical_conflicts", []),
            f"{week_key}_validated_qfq_basis_bridges": acceptance.get("validated_qfq_basis_bridges", {}),
            f"{week_key}_known_irreducible_gaps": acceptance.get("known_irreducible_gaps", []),
            "quarantine_included": False,
            "working_cache_included": False,
            "failed_outputs_included": False,
        }
    )
    spec.update(
        {
            "release_id": RELEASE_ID,
            "parent_release_id": parent_spec["release_id"],
            "parent_release_sha256": PARENT_SHA,
            "week_start": WEEK_START,
            "week_end": AS_OF,
            "latest_trade_date": AS_OF,
            "prepared_at": datetime.now(timezone.utc).isoformat(),
            "publication_purpose": "AUTHORIZED_ALL12_PIT_PARENT_NO_HISTORY_WRITE",
            "scope": SCOPE,
            "scope_symbols": TARGET_SYMBOLS,
            "scope_model_count": len(selected),
            "scope_consumption_input_count": len(inputs),
            "base_files": dict(sorted(base_files.items())),
            "release_files": release_files,
            "known_exceptions": known,
            "all_history_certified": False,
            "weekly_run_id": RUN_ID,
            "weekly_incremental_manifest_sha256": sha(RUN / "MANIFEST_SHA256_SIZE.txt"),
            "current_week_formal_member_count": len(current),
            "newly_pinned_model_input_member_count": len(added_members),
            "current_week_quarantine_member_count": len(
                [item for item in publication.get("written_files", []) if item.startswith("state/quarantine/")]
            ),
            "current_week_quarantine_included": False,
            "parent_prefix_identical_through": PREFIX_AS_OF,
            "pit_diagnostics_file": "PIT_DIAGNOSTICS.json",
            "target_input_diagnostics_file": "TARGET_INPUT_DIAGNOSTICS.json",
            "parent_prefix_proof_file": "PARENT_PREFIX_PROOF.json",
        }
    )
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from pit_source_lineage import enrich
    spec = enrich(candidate, DATABASE, PARENT, PARENT_SHA, Reader, spec, publication, dump_new, sha)
    dump_new(candidate / "release.json", spec)
    provisional_sha = sha(candidate / "release.json")
    dump_new(candidate / "COMMIT.json", {
        "status": "ACCEPTED_MANUAL_RELEASE",
        "private_candidate": True,
        "release_sha256": provisional_sha,
    })

    prefix_rows: list[dict[str, Any]] = []
    target_rows: list[dict[str, Any]] = []
    model_rows: list[dict[str, Any]] = []
    with Reader(DATABASE, PARENT, PARENT_SHA) as parent_reader, Reader(
        DATABASE, candidate, provisional_sha, allow_private=True
    ) as candidate_reader:
        for relative in inputs:
            if relative.endswith(".parquet"):
                before_frame = parent_reader.read_parquet(relative, PREFIX_AS_OF)
                after_frame = candidate_reader.read_parquet(relative, PREFIX_AS_OF)
                pd.testing.assert_frame_equal(before_frame, after_frame, check_exact=True)
                current_frame = candidate_reader.read_parquet(relative, AS_OF)
                minimum, maximum, rows = frame_bounds(current_frame)
                fresh = not relative.endswith("_raw.parquet") or maximum == AS_OF
                require(fresh, f"SCOPED_RAW_FRESHNESS_FAILED: {relative}:{maximum}")
                prefix_rows.append({
                    "relative": relative,
                    "as_of": PREFIX_AS_OF,
                    "visible_identical": True,
                    "rows": len(before_frame),
                })
                target_rows.append({
                    "relative": relative,
                    "kind": "parquet",
                    "min_date": minimum,
                    "max_date": maximum,
                    "rows": rows,
                    "raw_fresh": fresh,
                })
            else:
                before_json = parent_reader.read_json(relative, PREFIX_AS_OF, vintage="revised")
                after_json = candidate_reader.read_json(relative, PREFIX_AS_OF, vintage="revised")
                require(before_json["data"] == after_json["data"], f"PREFIX_JSON_DRIFT: {relative}")
                current_json = candidate_reader.read_json(relative, AS_OF, vintage="revised")
                prefix_rows.append({
                    "relative": relative,
                    "as_of": PREFIX_AS_OF,
                    "visible_identical": True,
                    "parent_pit_diagnostics": before_json["pit_diagnostics"],
                    "candidate_pit_diagnostics": after_json["pit_diagnostics"],
                })
                target_rows.append({
                    "relative": relative,
                    "kind": "json",
                    "pit_diagnostics": current_json["pit_diagnostics"],
                    "data_sha256": stable_sha(current_json["data"]),
                })
        for model in selected:
            reads = [row for row in target_rows if row["relative"] in model["inputs"]]
            require(len(reads) == len(model["inputs"]), f"MODEL_INPUT_READ_COUNT_MISMATCH: {model['symbol']}")
            if model['symbol'] == '01585.HK':
                from qwl_pit_gateway.audit_metadata import read_audit_metadata
                for relative in model['inputs']:
                    if relative.startswith('cache/hk_action_evidence/'):
                        read_audit_metadata(candidate_reader, relative,
                            candidate_reader.read_json(relative, AS_OF, vintage='revised'), symbol=model['symbol'])
            model_rows.append({
                "name": model["name"],
                "symbol": model["symbol"],
                "input_count": len(reads),
                "status": "MODEL_DATA_READY",
            })

    prefix_proof = {
        "schema_version": 1,
        "parent_release_sha256": PARENT_SHA,
        "comparison_as_of": PREFIX_AS_OF,
        "vintage": "revised",
        "logical_file_count": len(prefix_rows),
        "all_visible_parent_views_identical": True,
        "comparison_digest": stable_sha(prefix_rows),
        "items": prefix_rows,
    }
    pit = {
        "schema_version": 1,
        "release_id": RELEASE_ID,
        "as_of": AS_OF,
        "vintage": "revised",
        "scope": SCOPE,
        "model_count": len(model_rows),
        "model_input_count": len(inputs),
        "models": model_rows,
        "items": target_rows,
    }
    targets = {
        "schema_version": 1,
        "release_id": RELEASE_ID,
        "as_of": AS_OF,
        "vintage": "revised",
        "target_symbols": TARGET_SYMBOLS,
        "input_reads": len(target_rows),
        "failures": [],
        "all_required_raw_inputs_fresh": True,
    }
    dump_new(candidate / "PARENT_PREFIX_PROOF.json", prefix_proof)
    dump_new(candidate / "PIT_DIAGNOSTICS.json", pit)
    dump_new(candidate / "TARGET_INPUT_DIAGNOSTICS.json", targets)
    for relative in ("PARENT_PREFIX_PROOF.json", "PIT_DIAGNOSTICS.json", "TARGET_INPUT_DIAGNOSTICS.json"):
        spec["release_files"][relative] = sha(candidate / relative)
    spec["release_files"] = dict(sorted(spec["release_files"].items()))
    spec["parent_prefix_comparison_sha256"] = prefix_proof["comparison_digest"]
    spec["target_input_diagnostics_sha256"] = sha(candidate / "TARGET_INPUT_DIAGNOSTICS.json")
    (candidate / "COMMIT.json").unlink()
    (candidate / "release.json").unlink()
    dump_new(candidate / "release.json", spec)
    release_sha = sha(candidate / "release.json")

    dump_new(candidate / "AUTHORIZATION.json", {
        "schema_version": 1,
        "authorization_token": AUTHORIZATION,
        "authorization_context": "用户当前会话主动发起同周数据库更新，标准流程允许新增同周PIT release",
        "authorized_scope": "ONE_NEW_ALL12_PIT_PARENT_DIRECTORY_ONLY",
        "as_of": AS_OF,
        "historical_database_changes_authorized": False,
        "existing_release_changes_authorized": False,
        "plugin_skill_model_changes_authorized": False,
    })
    dump_new(candidate / "INPUT_ACCEPTANCE.json", {
        "schema_version": 1,
        "status": "PASS",
        "release_id": RELEASE_ID,
        "release_sha256": release_sha,
        "as_of": AS_OF,
        "model_count": len(selected),
        "model_input_count": len(inputs),
        "current_week_formal_member_count": len(current),
        "newly_pinned_member_count": len(added_members),
        "all_model_inputs_readable": True,
        "all_required_raw_inputs_fresh": True,
        "parent_prefix_identical": True,
        "quarantine_members_included": 0,
        "weekly_publication": {
            "run_id": RUN_ID,
            "status": publication["status"],
            "formal_existing_files_rewritten": publication["formal_existing_files_rewritten"],
            "historical_revisions_published": publication["historical_revisions_published"],
            "historical_backfills_published": publication["historical_backfills_published"],
        },
    })
    dump_new(candidate / "ENTRYPOINT.json", {
        "schema_version": 1,
        "release_id": RELEASE_ID,
        "release_root": str(TARGET),
        "release_sha256": release_sha,
        "database_root": str(DATABASE),
        "reader": str(READER),
        "as_of_and_vintage_required": True,
        "vintage": "revised",
        "latest_trade_date": AS_OF,
        "scope": SCOPE,
        "scope_symbols": TARGET_SYMBOLS,
        "weekly_run_id": RUN_ID,
        "historical_quality_restrictions_preserved": True,
        "model_or_plugin_changed": False,
    })

    release_relative = TARGET.relative_to(DATABASE)
    manifest_lines = []
    for path in sorted(candidate.rglob("*")):
        if path.is_file():
            relative = release_relative / path.relative_to(candidate)
            manifest_lines.append(f"{sha(path)}  {path.stat().st_size}  {relative}\n")
    with (candidate / "MANIFEST_SHA256_SIZE.txt").open("x", encoding="utf-8") as handle:
        handle.writelines(manifest_lines)
    dump_new(candidate / "COMMIT.json", {
        "status": "ACCEPTED_MANUAL_RELEASE",
        "private_candidate": False,
        "release_sha256": release_sha,
        "manifest_sha256": sha(candidate / "MANIFEST_SHA256_SIZE.txt"),
        "committed_at": datetime.now(timezone.utc).isoformat(),
        "purpose": "FORMAL_ALL12_PIT_PARENT_NO_HISTORY_CHANGE",
    })

    staging = Path(tempfile.mkdtemp(prefix=f".{RELEASE_ID}.staging-", dir=TARGET.parent))
    try:
        shutil.copytree(candidate, staging, dirs_exist_ok=True)
        require(sha(staging / "release.json") == release_sha, "STAGING_RELEASE_SHA_DRIFT")
        os.rename(staging, TARGET)
    except Exception:
        if staging.exists():
            shutil.rmtree(staging)
        raise

    with Reader(DATABASE, TARGET, release_sha) as reader:
        require(reader.spec["release_id"] == RELEASE_ID, "PUBLISHED_READER_RELEASE_MISMATCH")
        for relative in raw_inputs:
            _, maximum, _ = frame_bounds(reader.read_parquet(relative, AS_OF))
            require(maximum == AS_OF, f"POST_PUBLICATION_RAW_FRESHNESS_FAILED: {relative}:{maximum}")

    after = metadata_inventory(DATABASE)
    altered = sorted(relative for relative, meta in before.items() if after.get(relative) != meta)
    added = sorted(set(after) - set(before))
    prefix = str(TARGET.relative_to(DATABASE)) + "/"
    unexpected = [relative for relative in added if not relative.startswith(prefix)]
    require(not altered, "PRE_EXISTING_DATABASE_FILE_CHANGED")
    require(added and not unexpected, "DATABASE_WRITE_ESCAPED_NEW_RELEASE")
    result = {
        "schema_version": 1,
        "status": "PUBLISHED_ALL12_PIT_PARENT",
        "release_id": RELEASE_ID,
        "release_dir": str(TARGET),
        "entrypoint": str(TARGET / "ENTRYPOINT.json"),
        "release_sha256": release_sha,
        "manifest_sha256": sha(TARGET / "MANIFEST_SHA256_SIZE.txt"),
        "parent_release_id": parent_spec["release_id"],
        "parent_release_sha256": PARENT_SHA,
        "as_of": AS_OF,
        "model_count": len(selected),
        "model_input_count": len(inputs),
        "newly_pinned_member_count": len(added_members),
        "database_before": before_summary,
        "database_after": inventory_summary(after),
        "pre_existing_database_files_changed": altered,
        "added_database_files": added,
        "all_additions_inside_new_release": not unexpected,
        "quarantine_members_included": 0,
        "historical_data_files_changed": False,
        "old_releases_changed": False,
        "plugins_skills_or_models_changed": False,
        "job_sha256": sha(JOB),
        "publication_sha256": sha(RUN / "publication.json"),
        "incremental_catalog_sha256": sha(RUN / "incremental_catalog.json"),
    }
    dump_new(EVIDENCE / "PUBLICATION.json", result)
    return result


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    for name in ("as-of", "weekly-run-id", "job-path", "parent-release",
                 "parent-release-sha", "release-id", "evidence", "authorization"):
        result.add_argument("--" + name, required=True)
    return result


def configure(args: argparse.Namespace) -> None:
    global EVIDENCE, PARENT, PARENT_SHA, RUN_ID, RUN, JOB, RELEASE_ID
    global TARGET, AS_OF, PREFIX_AS_OF, WEEK_START, TARGET_SYMBOLS
    require(args.authorization == AUTHORIZATION, "CURRENT_WEEK_PARENT_AUTHORIZATION_REQUIRED")
    AS_OF = date.fromisoformat(args.as_of).isoformat()
    require(date.fromisoformat(AS_OF).weekday() == 4, "TARGET_MUST_BE_WEEK_FRIDAY")
    WEEK_START = (date.fromisoformat(AS_OF) - timedelta(days=4)).isoformat()
    PREFIX_AS_OF = (date.fromisoformat(AS_OF) - timedelta(days=7)).isoformat()
    require(len(args.parent_release_sha) == 64, "INVALID_PARENT_SHA")
    require(args.weekly_run_id == Path(args.weekly_run_id).name, "UNSAFE_WEEKLY_RUN_ID")
    require(args.release_id == Path(args.release_id).name, "UNSAFE_RELEASE_ID")
    releases = DATABASE / "state/pit_gateway/releases"
    PARENT = Path(args.parent_release).resolve()
    require(PARENT.is_relative_to(releases), "PARENT_NOT_FORMAL_RELEASE")
    PARENT_SHA = args.parent_release_sha
    RUN_ID = args.weekly_run_id
    RUN = DATABASE / "state/weekly_runs" / RUN_ID
    JOB = Path(args.job_path).resolve()
    require(JOB.name == "job.json" and JOB.parent.name == AS_OF
            and "weekly_jobs" in JOB.parts, "INVALID_WEEKLY_JOB_PATH")
    RELEASE_ID = args.release_id
    TARGET = releases / RELEASE_ID
    EVIDENCE = Path(args.evidence).resolve()
    require(EVIDENCE != PROJECT / "weekly_evidence"
            and EVIDENCE.is_relative_to(PROJECT / "weekly_evidence"),
            "EVIDENCE_OUTSIDE_WEEKLY_EVIDENCE")
    registry = load(REGISTRY)
    TARGET_SYMBOLS = [model["symbol"] for model in registry["models"]]
    require(len(TARGET_SYMBOLS) == len(set(TARGET_SYMBOLS)) == 12, "REGISTRY_NOT_EXACTLY_12")


def main() -> int:
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    try:
        configure(parser().parse_args())
        result = build()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        result = {"status": "BLOCKED", "error_type": type(exc).__name__, "error": str(exc)}
        blocked = EVIDENCE / "BLOCKED.json" if EVIDENCE is not None else None
        if blocked is not None and EVIDENCE.is_dir() and not blocked.exists():
            dump_new(blocked, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
