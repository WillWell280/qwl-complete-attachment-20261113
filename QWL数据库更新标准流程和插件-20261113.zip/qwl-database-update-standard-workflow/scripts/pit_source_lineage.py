"""Finite CSI300 adapter-header compatibility, never a price/availability waiver"""
from __future__ import annotations
import copy
import json
from datetime import datetime, timezone
from pathlib import Path

RELATIVE = 'cache/benchmarks/index_CSI300.json'
LABELS = frozenset({'tencent_raw', 'akshare_tx_index_raw'})


def prepare(parent_reader, candidate_reader, publication, as_of):
    """Return source-only operations proven not to change any other visible value"""
    cutoff = parent_reader.spec['week_end']
    before = parent_reader.read_json(RELATIVE, cutoff, vintage='revised')['data']
    after = candidate_reader.read_json(RELATIVE, cutoff, vintage='revised')['data']
    parent_base = parent_reader._document(RELATIVE, cutoff, 'base').get('source')
    candidate_base = candidate_reader._document(RELATIVE, as_of, 'base').get('source')
    if before == after and parent_base == candidate_base:
        return [], None
    if ({k:v for k,v in before.items() if k != 'source'} != {k:v for k,v in after.items() if k != 'source'}
            or before.get('source') not in LABELS or after.get('source') not in LABELS
            or parent_base not in LABELS or candidate_base not in LABELS):
        raise ValueError('unapproved PIT prefix drift; not a CSI300 source-only alias')
    # Observe the verified formal header locally now if the publisher has no
    # explicit clock. This is NOT a provider first-publication timestamp
    observed = publication.get('created_at') or publication.get('published_at') or publication.get('committed_at')
    observed = observed or datetime.now(timezone.utc).isoformat()
    stamp = datetime.fromisoformat(observed.replace('Z', '+00:00'))
    if stamp.tzinfo is None or stamp > datetime.now(timezone.utc) or stamp.date().isoformat() < as_of:
        raise ValueError('source identity observation clock invalid')
    from zoneinfo import ZoneInfo
    apply_on = stamp.astimezone(ZoneInfo('Asia/Shanghai')).date().isoformat()
    actual_source = candidate_reader._document(RELATIVE, as_of, 'base').get('source')
    if actual_source not in LABELS:
        raise ValueError('unknown CSI300 native source adapter')
    # Existing operation order is preserved. Restore the parent-visible
    # header from its cutoff; this is initial state, not publication evidence
    operations = [
        {'kind':'metadata','apply_on':'0001-01-01','values':{'source':parent_base},
         'clock_semantics':'exact_parent_header_initial_state_not_new_public_information'},
        {'kind':'metadata','apply_on':apply_on,'values':{'source':actual_source},
         'clock_semantics':'not_before_formal_source_publication_observation'},
    ]
    return operations, {'logical_file':RELATIVE,'field':'source','underlying_vendor':'Tencent',
        'observed_at':observed,'apply_on':apply_on,'parent_cutoff':cutoff,
        'parent_label':before['source'],'actual_native_label':actual_source,
        'clock_is_local_verified_header_observation_not_provider_publication':True,
        'certified_vintage':'revised','record_values_and_availability_changed':False,
        'base_vintage_is_raw_metadata_comparison_not_source_clock_certification':True}


def enrich(candidate, database, parent, parent_sha, Reader, spec, publication, dump, sha):
    """Prepare only a new private candidate before all native prefix gates"""
    provisional = copy.deepcopy(spec)
    dump(candidate / 'release.json', provisional)
    dump(candidate / 'COMMIT.json', {'status':'ACCEPTED_MANUAL_RELEASE','private_candidate':True,
        'release_sha256':sha(candidate / 'release.json')})
    with Reader(database, parent, parent_sha) as old, Reader(database,candidate,
            sha(candidate/'release.json'),allow_private=True) as new:
        operations, lineage = prepare(old,new,publication,spec['week_end'])
    if lineage:
        content = json.loads((candidate/'operations.json').read_text())
        content[RELATIVE] = [operations[0], *content.get(RELATIVE, []), operations[1]]
        (candidate/'operations.json').unlink()  # this uncommitted candidate only
        dump(candidate/'operations.json', content)
        spec['release_files']['operations.json'] = sha(candidate/'operations.json')
        dump(candidate/'SOURCE_METADATA_LINEAGE.json', lineage)
        spec['release_files']['SOURCE_METADATA_LINEAGE.json'] = sha(candidate/'SOURCE_METADATA_LINEAGE.json')
        spec['known_exceptions']['source_metadata_clock_compatibility'] = lineage
    # Fresh announcement audit partitions from exact pinned formal members
    (candidate/'release.json').unlink(); (candidate/'COMMIT.json').unlink()
    dump(candidate/'release.json',spec)
    dump(candidate/'COMMIT.json',{'status':'ACCEPTED_MANUAL_RELEASE','private_candidate':True,
        'release_sha256':sha(candidate/'release.json')})
    from weekly_plugin_runner.build_audit_sidecar import build
    with Reader(database,candidate,sha(candidate/'release.json'),allow_private=True) as reader:
        payload = build(reader,spec['week_end'],parent_release_sha256=parent_sha)
    if len(payload['files']) != 15:
        raise ValueError('fixed15 audit scope mismatch')
    relative = 'audit_metadata/hk_announcement_headers.json'
    dump(candidate/relative,payload)
    spec['release_files'][relative] = sha(candidate/relative)
    audit_reader = Path(parent_reader_path(spec)).with_name('audit_metadata.py')
    spec['audit_metadata_extension'] = {'path':relative,'reader':str(audit_reader),
        'reader_sha256':sha(audit_reader),'covered_models':['01585.HK'],'parent_release_sha256':parent_sha}
    (candidate/'release.json').unlink(); (candidate/'COMMIT.json').unlink()
    return spec


def parent_reader_path(spec):
    # The existing descriptor pins Reader by SHA; the project location is fixed
    return '/Users/bytedance/Documents/ChatGPT/量化交易/qwl_pit_gateway/reader.py'
