#!/usr/bin/env python3
"""Publish one append-only PIT release covering all 12 registered models

The command never collects data, changes an existing database file, edits a
model/plugin, or consumes quarantine.  It only admits current-week formal
published-version members already accepted by the QWL weekly run, validates
all declared model inputs privately, and atomically adds one release directory
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import os
import shutil
import sys
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any


FIXED_DATABASE = Path("/Users/bytedance/Desktop/60只股票全量历史数据_20260816")
FIXED_PROJECT = Path("/Users/bytedance/Documents/ChatGPT/量化交易")
AUTHORIZATION = "PUBLISH_ALL12_PIT_CURRENT_WEEK"


class PublicationError(RuntimeError):
    pass


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode()


def dump_new(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write("\n")


def metadata_inventory(root: Path) -> dict[str, tuple[int, int, int]]:
    result: dict[str, tuple[int, int, int]] = {}
    for path in sorted(root.rglob("*")):
        if path.is_file():
            if path.is_symlink():
                raise PublicationError(f"DATABASE_SYMLINK_REJECTED: {path}")
            stat = path.stat()
            result[str(path.relative_to(root))] = (
                stat.st_size,
                stat.st_mtime_ns,
                stat.st_mode,
            )
    return result


def inventory_summary(rows: dict[str, tuple[int, int, int]]) -> dict[str, Any]:
    return {
        "file_count": len(rows),
        "metadata_sha256": hashlib.sha256(canonical(sorted(rows.items()))).hexdigest(),
    }


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_reader(project: Path):
    path = project / "qwl_pit_gateway" / "reader.py"
    spec = importlib.util.spec_from_file_location("all12_pit_release_reader", path)
    if spec is None or spec.loader is None:
        raise PublicationError("GATEWAY_READER_IMPORT_FAILED")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Reader, path


def frame_bounds(frame) -> tuple[str | None, str | None, int]:
    import pandas as pd

    if frame.empty:
        return None, None, 0
    if "date" in frame.columns:
        values = pd.to_datetime(frame["date"])
    elif "timestamp" in frame.columns:
        values = pd.to_datetime(frame["timestamp"], utc=True).dt.tz_convert("Asia/Shanghai")
    else:
        values = pd.to_datetime(frame.index)
    minimum = pd.Timestamp(values.min()).date().isoformat()
    maximum = pd.Timestamp(values.max()).date().isoformat()
    return minimum, maximum, int(len(frame))


def validate_args(args: argparse.Namespace) -> tuple[Path, Path, Path, Path]:
    database = Path(args.database).resolve()
    project = Path(args.project).resolve()
    if database != FIXED_DATABASE.resolve():
        raise PublicationError("WRONG_FIXED_DATABASE")
    if project != FIXED_PROJECT.resolve():
        raise PublicationError("WRONG_PROJECT_ROOT")
    date.fromisoformat(args.as_of)
    if args.authorization != AUTHORIZATION:
        raise PublicationError("EXPLICIT_CURRENT_WEEK_RELEASE_AUTHORIZATION_REQUIRED")

    releases = database / "state" / "pit_gateway" / "releases"
    parent = Path(args.parent_release).resolve()
    if not parent.is_relative_to(releases):
        raise PublicationError("PARENT_NOT_A_FORMAL_RELEASE")
    if len(args.parent_release_sha) != 64:
        raise PublicationError("INVALID_PARENT_RELEASE_SHA")
    target = releases / args.release_id
    if target.exists():
        raise PublicationError("TARGET_RELEASE_ALREADY_EXISTS")
    if args.supersedes_release_id:
        superseded = releases / args.supersedes_release_id
        if not superseded.is_dir() or superseded == target:
            raise PublicationError("INVALID_SUPERSEDED_RELEASE")

    evidence = Path(args.evidence).resolve()
    evidence_root = (project / "weekly_evidence").resolve()
    if evidence == evidence_root or not evidence.is_relative_to(evidence_root):
        raise PublicationError("EVIDENCE_MUST_BE_A_NEW_CHILD_OF_WEEKLY_EVIDENCE")
    if evidence.exists():
        raise PublicationError("EVIDENCE_ALREADY_EXISTS")
    if project.stat().st_dev != releases.stat().st_dev:
        raise PublicationError("ATOMIC_PUBLICATION_REQUIRES_SAME_FILESYSTEM")
    return database, project, parent, target


def validate_weekly_publication(database: Path, run_id: str, as_of: str) -> tuple[dict, dict, Path]:
    run = database / "state" / "weekly_runs" / run_id
    publication_path = run / "publication.json"
    catalog_path = run / "incremental_catalog.json"
    manifest_path = run / "MANIFEST_SHA256_SIZE.txt"
    if not publication_path.is_file() or not catalog_path.is_file() or not manifest_path.is_file():
        raise PublicationError("WEEKLY_RUN_EVIDENCE_INCOMPLETE")
    publication = load_json(publication_path)
    catalog = load_json(catalog_path)
    checks = {
        "status": publication.get("status") == "PUBLISHED",
        "week_end": publication.get("week_end") == as_of,
        "formal_existing_files_rewritten": publication.get("formal_existing_files_rewritten") == 0,
        "historical_revisions_published": publication.get("historical_revisions_published") == 0,
        "historical_backfills_published": publication.get("historical_backfills_published") == 0,
        "formal_acceptance": publication.get("formal_acceptance", {}).get("passed") is True,
        "run_id": catalog.get("run_id") == run_id,
    }
    failed = sorted(name for name, passed in checks.items() if not passed)
    if failed:
        raise PublicationError("WEEKLY_PUBLICATION_NOT_ACCEPTED: " + ",".join(failed))
    return publication, catalog, manifest_path


def build(args: argparse.Namespace) -> dict[str, Any]:
    database, project, parent, target = validate_args(args)
    if Path(args.registry).resolve() != (project/'weekly_plugin_runner/registry.json').resolve():
        raise PublicationError('WRONG_RUNNER_REGISTRY')
    parent_descriptor = load_json(parent / 'release.json')
    if parent_descriptor.get('week_end') != args.as_of:
        # The parent builder already admits the full all12 closure. Build and
        # publish it once, including source lineage and fresh audit partitions
        module_spec = importlib.util.spec_from_file_location('qwl_current_week_builder',
            Path(__file__).with_name('build_current_week_parent.py'))
        builder = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(builder)
        key = hashlib.sha256(str(database).encode()).hexdigest()[:16]
        runtime = Path('/Users/bytedance/Desktop/bytedance/扣子/Trae对话/量化炒股Plugin-自选股/quant-watchlist-plugin')
        Path(args.evidence).mkdir(parents=True, exist_ok=False)
        builder.configure(argparse.Namespace(as_of=args.as_of, weekly_run_id=args.weekly_run_id,
            job_path=str(runtime/'state/weekly_jobs'/key/args.as_of/'job.json'),
            parent_release=str(parent), parent_release_sha=args.parent_release_sha,
            release_id=args.release_id, evidence=args.evidence, authorization='PUBLISH_WEEKLY_PIT_CURRENT_WEEK'))
        builder.SCOPE = 'ALL_12_MODEL_CONSUMPTION_CLOSURE'
        return builder.build()
    registry_path = Path(args.registry).resolve()
    if registry_path != (project / "weekly_plugin_runner" / "registry.json").resolve():
        raise PublicationError("WRONG_RUNNER_REGISTRY")
    registry = load_json(registry_path)
    models = registry.get("models")
    if not isinstance(models, list) or len(models) != 12:
        raise PublicationError("REGISTRY_MUST_CONTAIN_EXACTLY_12_MODELS")
    symbols = [model.get("symbol") for model in models]
    if len(set(symbols)) != 12 or any(not value for value in symbols):
        raise PublicationError("REGISTRY_SYMBOLS_NOT_UNIQUE")
    all_inputs = sorted({path for model in models for path in model.get("inputs", [])})
    if not all_inputs:
        raise PublicationError("EMPTY_MODEL_INPUT_CLOSURE")

    publication, catalog, weekly_manifest = validate_weekly_publication(
        database, args.weekly_run_id, args.as_of
    )
    Reader, reader_path = load_reader(project)
    before = metadata_inventory(database)
    before_summary = inventory_summary(before)

    with Reader(database, parent, args.parent_release_sha) as parent_reader:
        parent_spec = copy.deepcopy(parent_reader.spec)
    if parent_spec.get("week_end") != args.as_of or parent_spec.get("latest_trade_date") != args.as_of:
        raise PublicationError("PARENT_RELEASE_NOT_PINNED_TO_TARGET_WEEK")
    if parent_spec.get("reader_sha256") != sha256(reader_path):
        raise PublicationError("PARENT_READER_HASH_MISMATCH")
    for logical in all_inputs:
        if logical not in parent_spec.get("logical_files", []):
            raise PublicationError(f"MODEL_INPUT_NOT_AUTHORIZED_BY_PARENT: {logical}")
        if logical not in parent_spec.get("base_files", {}):
            raise PublicationError(f"MODEL_BASE_INPUT_NOT_PINNED_BY_PARENT: {logical}")

    input_prefixes = tuple(f"state/published_versions/{path}/" for path in all_inputs)
    entries = catalog.get("entries")
    if not isinstance(entries, list):
        raise PublicationError("INVALID_INCREMENTAL_CATALOG_ENTRIES")
    current_members: dict[str, str] = {}
    for entry in entries:
        relative = entry.get("relative")
        expected = entry.get("sha256")
        if not isinstance(relative, str) or not relative.startswith(input_prefixes):
            continue
        path = database / relative
        if not path.is_file() or path.stat().st_size != entry.get("bytes") or sha256(path) != expected:
            raise PublicationError(f"FORMAL_WEEKLY_MEMBER_DRIFT: {relative}")
        current_members[relative] = expected

    raw_paths = sorted(path for path in all_inputs if path.endswith("_raw.parquet"))
    missing_current_raw = [
        path
        for path in raw_paths
        if not any(member.startswith(f"state/published_versions/{path}/") for member in current_members)
    ]
    if missing_current_raw:
        raise PublicationError("RAW_INPUTS_ABSENT_FROM_CURRENT_WEEK_FORMAL_RUN: " + ",".join(missing_current_raw))

    base_files = copy.deepcopy(parent_spec["base_files"])
    added_members: list[str] = []
    for relative, expected in sorted(current_members.items()):
        previous = base_files.get(relative)
        if previous is not None and previous != expected:
            raise PublicationError(f"PARENT_MEMBER_HASH_CONFLICT: {relative}")
        if previous is None:
            base_files[relative] = expected
            added_members.append(relative)
    if not added_members:
        raise PublicationError("NO_NEW_MODEL_CLOSURE_MEMBERS_TO_PUBLISH")

    evidence = Path(args.evidence).resolve()
    evidence.mkdir(parents=True, exist_ok=False)
    stage = evidence / "private-release"
    stage.mkdir()

    operations_source = parent / "operations.json"
    operations_target = stage / "operations.json"
    shutil.copy2(operations_source, operations_target)
    release_files = {"operations.json": sha256(operations_target)}

    spec = copy.deepcopy(parent_spec)
    for key in (
        "parent_prefix_comparison_sha256",
        "parent_prefix_identical_through",
        "parent_prefix_proof_file",
        "pit_diagnostics_file",
        "target_input_diagnostics_file",
        "target_input_diagnostics_sha256",
    ):
        spec.pop(key, None)
    spec.pop("audit_metadata_extension", None)
    spec.update(
        {
            "release_id": args.release_id,
            "prepared_at": datetime.now(timezone.utc).isoformat(),
            "parent_release_id": parent_spec["release_id"],
            "parent_release_sha256": args.parent_release_sha,
            "base_files": dict(sorted(base_files.items())),
            "release_files": dict(sorted(release_files.items())),
            "scope": "ALL_12_MODEL_CONSUMPTION_CLOSURE",
            "scope_symbols": symbols,
            "scope_model_count": 12,
            "scope_consumption_input_count": len(all_inputs),
            "publication_purpose": "AUTHORIZED_FORMAL_ALL12_MODEL_PIT_BRIDGE_NO_HISTORY_WRITE",
            "weekly_run_id": args.weekly_run_id,
            "weekly_incremental_manifest_sha256": sha256(weekly_manifest),
            "current_week_model_input_member_count": len(current_members),
            "newly_pinned_model_input_member_count": len(added_members),
            "quarantine_members_included": 0,
            "all_history_certified": False,
        }
    )
    if args.supersedes_release_id:
        spec["supersedes_release_id"] = args.supersedes_release_id
        spec["supersession_reason"] = (
            "PRIOR_ALL12_RELEASE_FAILED_PUBLIC_PREFLIGHT_STALE_HK_AUDIT_SIDECAR"
        )
    dump_new(stage / "release.json", spec)
    release_sha = sha256(stage / "release.json")
    dump_new(
        stage / "COMMIT.json",
        {
            "status": "ACCEPTED_MANUAL_RELEASE",
            "private_candidate": True,
            "release_sha256": release_sha,
        },
    )

    # Rebuild the audit-only HK announcement sidecar from the exact pinned
    # members of this candidate. Copying the parent sidecar would leave new
    # weekly records unattested and correctly block Yadea at preflight
    sys.path.insert(0, str(project))
    from weekly_plugin_runner.build_audit_sidecar import build as build_audit_sidecar

    with Reader(database, stage, release_sha, allow_private=True) as preliminary_reader:
        audit_payload = build_audit_sidecar(
            preliminary_reader,
            args.as_of,
            parent_release_sha256=args.parent_release_sha,
        )
    audit_relative = "audit_metadata/hk_announcement_headers.json"
    audit_path = stage / audit_relative
    dump_new(audit_path, audit_payload)
    spec["release_files"][audit_relative] = sha256(audit_path)
    spec["release_files"] = dict(sorted(spec["release_files"].items()))
    audit_reader_path = project / "qwl_pit_gateway" / "audit_metadata.py"
    spec["audit_metadata_extension"] = {
        "path": audit_relative,
        "reader": str(audit_reader_path),
        "reader_sha256": sha256(audit_reader_path),
        "covered_models": ["01585.HK"],
        "parent_release_sha256": args.parent_release_sha,
    }
    (stage / "COMMIT.json").unlink()
    (stage / "release.json").unlink()
    dump_new(stage / "release.json", spec)
    release_sha = sha256(stage / "release.json")
    dump_new(
        stage / "COMMIT.json",
        {
            "status": "ACCEPTED_MANUAL_RELEASE",
            "private_candidate": True,
            "release_sha256": release_sha,
        },
    )

    model_results: list[dict[str, Any]] = []
    all_reads_pass = True
    all_raw_fresh = True
    with Reader(database, stage, release_sha, allow_private=True) as reader:
        for model in models:
            reads: list[dict[str, Any]] = []
            for relative in model["inputs"]:
                try:
                    if relative.endswith(".json"):
                        envelope = reader.read_json(relative, args.as_of, vintage="revised")
                        audit_segments = None
                        if model["symbol"] == "01585.HK" and relative.startswith(
                            "cache/hk_action_evidence/"
                        ):
                            from qwl_pit_gateway.audit_metadata import read_audit_metadata

                            audited = read_audit_metadata(
                                reader,
                                relative,
                                envelope,
                                symbol=model["symbol"],
                            )
                            audit_segments = len(audited["audit_windows"])
                        reads.append(
                            {
                                "path": relative,
                                "status": "READ_PASS",
                                "pit_diagnostics": envelope["pit_diagnostics"],
                                "audit_segments": audit_segments,
                            }
                        )
                    else:
                        frame = reader.read_parquet(relative, args.as_of)
                        minimum, maximum, rows = frame_bounds(frame)
                        fresh = not relative.endswith("_raw.parquet") or maximum == args.as_of
                        all_raw_fresh = all_raw_fresh and fresh
                        reads.append(
                            {
                                "path": relative,
                                "status": "READ_PASS",
                                "min_date": minimum,
                                "max_date": maximum,
                                "rows": rows,
                                "raw_fresh": fresh,
                            }
                        )
                except Exception as exc:
                    all_reads_pass = False
                    reads.append(
                        {
                            "path": relative,
                            "status": "READ_FAIL",
                            "error_type": type(exc).__name__,
                            "error": str(exc),
                        }
                    )
            model_ready = all(row["status"] == "READ_PASS" for row in reads) and all(
                row.get("raw_fresh", True) for row in reads
            )
            model_results.append(
                {
                    "name": model["name"],
                    "symbol": model["symbol"],
                    "input_count": len(reads),
                    "status": "MODEL_DATA_READY" if model_ready else "BLOCKED",
                    "reads": reads,
                }
            )
    if not all_reads_pass or not all_raw_fresh or not all(row["status"] == "MODEL_DATA_READY" for row in model_results):
        raise PublicationError("PRIVATE_ALL12_INPUT_ACCEPTANCE_FAILED")

    authorization = {
        "schema_version": 1,
        "authorized_scope": "ONE_NEW_ALL12_PIT_RELEASE_DIRECTORY_ONLY",
        "authorization_token": args.authorization,
        "authorization_context": "用户明确批准按方案修复并固化后续每周流程",
        "as_of": args.as_of,
        "historical_database_changes_authorized": False,
        "existing_release_changes_authorized": False,
        "plugin_or_model_changes_authorized": False,
        "supersedes_release_id": args.supersedes_release_id,
    }
    acceptance = {
        "schema_version": 1,
        "status": "PASS",
        "release_id": args.release_id,
        "release_sha256": release_sha,
        "as_of": args.as_of,
        "model_count": len(model_results),
        "model_input_count": len(all_inputs),
        "current_week_formal_model_member_count": len(current_members),
        "newly_pinned_member_count": len(added_members),
        "newly_pinned_members": added_members,
        "all_model_inputs_readable": all_reads_pass,
        "all_required_raw_inputs_fresh": all_raw_fresh,
        "hk_announcement_audit_sidecar_rebuilt": True,
        "supersedes_release_id": args.supersedes_release_id,
        "models": model_results,
        "weekly_publication": {
            "run_id": args.weekly_run_id,
            "status": publication["status"],
            "formal_existing_files_rewritten": publication["formal_existing_files_rewritten"],
            "historical_revisions_published": publication["historical_revisions_published"],
            "historical_backfills_published": publication["historical_backfills_published"],
        },
    }
    entrypoint = {
        "schema_version": 1,
        "release_id": args.release_id,
        "release_root": str(target),
        "release_sha256": release_sha,
        "database_root": str(database),
        "reader": str(reader_path),
        "as_of_and_vintage_required": True,
        "vintage": "revised",
        "latest_trade_date": args.as_of,
        "scope": spec["scope"],
        "scope_symbols": symbols,
        "weekly_run_id": args.weekly_run_id,
        "historical_quality_restrictions_preserved": True,
        "model_or_plugin_changed": False,
    }
    (stage / "COMMIT.json").unlink()
    dump_new(stage / "AUTHORIZATION.json", authorization)
    dump_new(stage / "INPUT_ACCEPTANCE.json", acceptance)
    dump_new(stage / "ENTRYPOINT.json", entrypoint)

    release_relative = target.relative_to(database)
    manifest_lines = []
    for path in sorted(stage.rglob("*")):
        if path.is_file():
            relative = release_relative / path.relative_to(stage)
            manifest_lines.append(f"{sha256(path)}  {path.stat().st_size}  {relative}\n")
    manifest = stage / "MANIFEST_SHA256_SIZE.txt"
    with manifest.open("x", encoding="utf-8") as handle:
        handle.writelines(manifest_lines)
    dump_new(
        stage / "COMMIT.json",
        {
            "status": "ACCEPTED_MANUAL_RELEASE",
            "private_candidate": False,
            "release_sha256": release_sha,
            "manifest_sha256": sha256(manifest),
            "committed_at": datetime.now(timezone.utc).isoformat(),
            "purpose": "FORMAL_ALL12_MODEL_PIT_RELEASE_NO_MODEL_OR_HISTORY_CHANGE",
        },
    )

    os.rename(stage, target)
    with Reader(database, target, release_sha) as reader:
        for relative in raw_paths:
            _, maximum, _ = frame_bounds(reader.read_parquet(relative, args.as_of))
            if maximum != args.as_of:
                raise PublicationError(f"POST_PUBLICATION_RAW_FRESHNESS_FAILED: {relative}")

    after = metadata_inventory(database)
    altered = sorted(relative for relative, meta in before.items() if after.get(relative) != meta)
    added = sorted(set(after) - set(before))
    prefix = str(target.relative_to(database)) + "/"
    unexpected_added = [relative for relative in added if not relative.startswith(prefix)]
    if altered or unexpected_added:
        raise PublicationError("UNEXPECTED_DATABASE_MUTATION_AFTER_PUBLICATION")
    result = {
        "schema_version": 1,
        "status": "PUBLISHED_ALL12_PIT_RELEASE",
        "release_id": args.release_id,
        "release_dir": str(target),
        "entrypoint": str(target / "ENTRYPOINT.json"),
        "release_sha256": release_sha,
        "manifest_sha256": sha256(target / "MANIFEST_SHA256_SIZE.txt"),
        "parent_release_id": parent_spec["release_id"],
        "parent_release_sha256": args.parent_release_sha,
        "supersedes_release_id": args.supersedes_release_id,
        "as_of": args.as_of,
        "model_count": 12,
        "model_input_count": len(all_inputs),
        "newly_pinned_member_count": len(added_members),
        "newly_pinned_members": added_members,
        "database_before": before_summary,
        "database_after": inventory_summary(after),
        "pre_existing_database_files_changed": altered,
        "added_database_files": added,
        "all_additions_inside_new_release": not unexpected_added,
        "historical_data_files_changed": False,
        "old_releases_changed": False,
        "plugins_or_models_changed": False,
    }
    dump_new(evidence / "PUBLICATION.json", result)
    return result


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--database", required=True)
    result.add_argument("--project", required=True)
    result.add_argument("--registry", required=True)
    result.add_argument("--parent-release", required=True)
    result.add_argument("--parent-release-sha", required=True)
    result.add_argument("--weekly-run-id", required=True)
    result.add_argument("--as-of", required=True)
    result.add_argument("--release-id", required=True)
    result.add_argument("--supersedes-release-id")
    result.add_argument("--authorization", required=True)
    result.add_argument("--evidence", required=True)
    return result


def main() -> int:
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    try:
        result = build(parser().parse_args())
        print(json.dumps(result, ensure_ascii=False, indent=2))
    except Exception as exc:
        print(
            json.dumps(
                {"status": "BLOCKED", "error_type": type(exc).__name__, "error": str(exc)},
                ensure_ascii=False,
                indent=2,
            )
        )
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
