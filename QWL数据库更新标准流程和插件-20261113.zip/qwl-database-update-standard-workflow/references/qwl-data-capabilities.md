# 已整合的QWL数据能力

本参考吸收原 `qwl-stock-data` Skill 的工具路由，用于解释和查询固定60只数据，或在用户明确请求时执行非正式周发布的数据刷新

**正式数据库周更始终按 [当前有效流程](effective-procedure.md) 执行，唯一写入口仍是 `qwl_weekly_update`**。本参考列出的普通刷新及全量刷新工具不得指向正式周更数据库，也不能代替候选视图验收、追加发布和发布后回读

## 共同前置与边界

1. 先调用 `qwl_data_health`，确认 canonical QWL runtime、Python环境、固定插件版本与冻结状态可用
2. 调用 `qwl_list_fixed_60` 核对唯一合法股票池，要求60只、45 A＋15 HK，不因用户输入增减或替换股票
3. 采集只使用QWL插件的MCP工具，不另行拼装未经授权的抓取脚本
4. 需要完整性结论时调用 `qwl_data_coverage_status`；每次普通刷新后用 `refresh=true` 重新审计，并同时报告 `freshness_complete`、`history_consistency_complete` 与已知限制
5. 结果区分成功、源空窗、失败、超时、不适用、停止披露与授权／商业源限制，不能把缺失或未达披露阈值写成零
6. 只可声明固定60只和已定义数据域的可获得来源通过审计，不可声称“市场全部数据完整”
7. 预测和回测不得直接读工作缓存、隔离层或仅基础文件，继续遵守项目批准的PIT读取入口

## 按请求选择工具

| 用户请求 | QWL工具 | 限制 |
|---|---|---|
| 查询股票池、单股现状或库存 | `qwl_list_fixed_60`、`qwl_symbol_data_status`、`qwl_data_inventory` | 只读；需要完整性结论时补覆盖审计 |
| 日常行情与实时快照 | `qwl_refresh_market_data(as_of_date)` | 原生OHLCV、交易日、快照、汇率及未来日期门禁 |
| 财报季与公告 | `qwl_refresh_fundamentals` → `qwl_refresh_financial_events` → `qwl_refresh_historical_evidence` | 明确来源发布时间，不把报告期当可得日 |
| 资金、两融、互联互通、股本和微观结构 | `qwl_refresh_gap_data` | 不适用、停止披露和源缺失分别标记 |
| 股东、研报、新闻、宏观与港股卖空 | `qwl_refresh_p2_data` | 不把最新快照冒充完整历史 |
| BYD、安克等固定池专项 | `qwl_refresh_specialized_data` | 不扩大固定股票池 |
| 用户明确要求普通全量刷新 | `qwl_refresh_all_data` | 逐阶段核验，顶层 `OK` 不是充分证据；不得用于正式周更发布 |
| 个人正式版本周更新 | `qwl_weekly_update` | 必须回到 [当前有效流程](effective-procedure.md)，不得使用上列普通工具替代 |

普通刷新后的结果至少报告截至时间、股票池、各阶段 cached／failed／timeout／empty／ineligible 数量、fatal／warn、覆盖审计状态、变动文件和不可消除缺口

## 按需读取的原插件参考资料

- 数据源与兜底：[01-data-sources.md](qwl-stock-data/01-data-sources.md)
- PIT与记录质量：[02-pit-quality.md](qwl-stock-data/02-pit-quality.md)
- MCP工具参数和操作细节：[03-operations.md](qwl-stock-data/03-operations.md)
- 已知且不可补造的缺口：[04-known-gaps.md](qwl-stock-data/04-known-gaps.md)
- 固定股票池和存储层：[05-universe-storage.md](qwl-stock-data/05-universe-storage.md)
- 插件周发布契约：[06-weekly-publication.md](qwl-stock-data/06-weekly-publication.md)

上述原插件资料是工具和底层契约参考，不授予跨周补录、历史修订、重冻结、普通工具写正式数据库或调度自动启动的权限。若描述与手动周更步骤有差异，先遵守本技能的 [当前有效流程](effective-procedure.md) 和实际冻结插件门禁；不能靠改写说明绕过工具阻断


周更维护版weekly-recovery.20261031的明确qfq来源、逐日公告凭证、窄范围仅隔离规则与阶段恢复限制见 effective-procedure.md；这些能力不授予历史修订、旧阻断自动解锁、模型变更或跨周授权
