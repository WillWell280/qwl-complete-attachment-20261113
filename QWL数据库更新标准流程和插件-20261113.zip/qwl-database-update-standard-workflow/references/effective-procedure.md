# 当前有效的QWL手动周更流程

## 固定环境

- 用途：个人正式版
- 数据库：`/Users/bytedance/Desktop/60只股票全量历史数据_20260816`
- Canonical runtime：`/Users/bytedance/Desktop/bytedance/扣子/Trae对话/量化炒股Plugin-自选股/quant-watchlist-plugin`
- Python：`/Users/bytedance/Desktop/bytedance/扣子/Trae对话/量化炒股Plugin-自选股/quant-watchlist-plugin/.venv/bin/python`
- 已安装Plugin：`/Users/bytedance/.codex/plugins/cache/qwl-stock-data-local/qwl-stock-data/1.2.1+codex.20260926`
- 运行契约：`weekly-contract.20260906`
- 工程维护版：`weekly-recovery.20261031`，不迁移安装目录、不清空旧检查点
- 已整合插件资料：`references/qwl-data-capabilities.md` 与 `references/qwl-stock-data/`，独立Skill仍保留作直接使用插件时的兼容入口
- 冻结清单：`/Users/bytedance/.codex/qwl-stock-data-freeze/frozen_sources.json`
- 检查点：Canonical runtime下的 `state/weekly_jobs/<database-key>/<as_of>/job.json`

所有Python调用设置 `PYTHONDONTWRITEBYTECODE=1` 并使用 `-B`

## 手动发起与目标日期

本技能没有执行时间、RRULE、定时唤醒或后台续跑调度。只有用户手动调用或明确要求执行QWL数据库更新时才启动、续跑或检查

用户可以在任何时间发起。用户未指定目标周时，`as_of_date` 取最近一个已经完成的交易周的星期五，数据窗口是对应星期一至星期五；用户指定目标周时使用该目标，但必须先检查现有检查点、日期有效性和底层QWL授权边界

技能可以随时被调用，不代表底层冻结QWL入口一定允许跨周写入。若入口返回 `AUTHORIZATION_REQUIRED_CROSS_WEEK` 或其他日期门禁，保留检查点并向用户报告，不得改日期、改代码或复用过期授权绕过

不得因使用本技能而创建、更新或依赖任何自动化任务。执行和进度展示均留在用户发起的当前会话中

## 启动前检查

按顺序执行：

1. 调用 `qwl_data_health`
2. 要求 `ok=true`、`runtime_revision=weekly-contract.20260906`、`frozen_sources.ok=true` 且无漂移
3. 调用 `qwl_list_fixed_60`，要求唯一60只、45 A＋15 HK
4. 调用 `qwl_weekly_status(as_of_date)`
5. 检查系统进程，确认是否已有同周 `weekly_cli`、`qwl_data_mcp` 或 `weekly_worker`

若当前会话未加载正确MCP工具，使用新stdio连接：

```text
<canonical-python> -B <installed-plugin>/scripts/weekly_cli.py health
<canonical-python> -B <installed-plugin>/scripts/weekly_cli.py status --as-of YYYY-MM-DD
<canonical-python> -B <installed-plugin>/scripts/weekly_cli.py update --as-of YYYY-MM-DD
```

`weekly_cli.py` 只转发同一QWL MCP工具，不是替代采集器。路径含空格或中文时必须正确引用

## 状态路由

- `NOT_STARTED`：仅在用户本次明确发起且底层QWL入口接受目标日期时启动该目标周任务
- `RUNNING` / `PUBLISHING`：先核对原进程；进程存活则只监控，原进程已退出才恢复同一检查点
- `WAITING_SOURCE` / `WAITING_RETRY`：只有到达 `next_retry_at` 后才在当前手动会话中调用同一更新入口；若会话已结束，等待用户再次手动发起
- `COMPLETE`：核验完整成功条件后不重复运行或发布
- `BLOCKED_*`：停止写入并报告证据，不得靠重试、改代码、清检查点或降级数据绕过
- `AUTHORIZATION_REQUIRED_CROSS_WEEK`：只报告并请求单独授权，不执行旧周写入
- `older_pending_jobs`：旧周只报告，不自动恢复

遇到非人工会话或进程异常，先检查原进程和同一检查点。原进程仍存活则继续等待；已退出且目标日期仍获底层入口接受时恢复同一检查点，当前手动执行最多自动恢复6次，不删除检查点、不清零attempt

## 唯一执行入口

本周正式更新调用：

```text
qwl_weekly_update(
  as_of_date=<当前周星期五>,
  database_root=/Users/bytedance/Desktop/60只股票全量历史数据_20260816,
  publish=true,
  authorization=PUBLISH_CURRENT_WEEK,
  include_specialized=true
)
```

禁止直接调用原生采集器写正式数据库，也禁止把普通全量刷新工具指向正式数据库

## 重试与恢复

同周已通过并具有可验证回执、不可变快照和内容哈希的项目不重采。失败项按股票、数据域、日期或文档继续处理

瞬时失败采用1、2、4、8、16分钟退避，第6次及以后至少等待1小时；`next_retry_at` 是最早时间，不允许无间隔循环

普通单股或单文档最长150秒，财报隔离上限仍为420秒，财务指标180秒、上市观测300秒；后两类每次运行各自合计不超过1500秒，未完成项持久化等待，不能通过拆分扩大总预算。子进程组结束后才读取输出；失败原始快照保留，但失败输出不得覆盖已接受工作缓存

财务指标和上市观测逐股核对来源、字段与本周真实观测后复用成功回执；财务指标每周首次需重新观察来源，旧TTL缓存不能代替本周源检查。行情按股票与raw/qfq口径保存不可变成功快照，仅续采失败序列，完整固定60只市场质量门禁仍须整体通过。内部断流最多恢复6次，安全阻断不进入自动解锁

意外中断的发布目录由锁和孤儿目录门禁处理，禁止手工删除或把部分发布视为完成

## 数据和历史保护

- raw日线只对应不复权来源
- 标准化日线只接受明确qfq来源
- 不得用raw补标准化序列
- qfq重基、既有重叠值变化或未来参考污染默认阻断。只有历史差异全部早于本周、本周 qfq/raw 逐字段相等、周前正式收盘锚点相等且无本周公司行动时，才可隔离历史差异并原值追加本周数据。本周除净导致重基时，只有明确及时的公司行动证据、除净前稳定因子和完整周内验收同时通过，才可以周前正式收盘为锚点生成 `qfq_chain_v1` 本周追加版本，历史仍不改写
- 旧快照缺少明确qfq参考时只标记 `basis_unverified`，不得宣称历史已修正或模型安全
- 跨周qfq桥接优先核对上周成功回执及供应商快照；若其中的临时文件已缺失，仅在上周已完成且正式发布清单绑定的桥接证据、正式行情版本、唯一原始快照及逐字段业务值哈希全部吻合时读取原桥接证明，不补造回执、不改写检查点、不借此放行本周其他安全阻断
- 供应商全量响应保存在不可变压缩快照
- 本周新增写入 `state/published_versions`
- 旧事件首次补录、历史业务键变化、未来日期和日期不明记录写入 `state/quarantine`
- 隔离层不得用于模型、回测或交易决策
- 正式读取必须合并冻结基础层和已发布版本层，并拒绝重复业务键

沪市两融只有在已知来源、SSE五字段形状和正式共享值逐项完全相等时才能复用旧记录；新日期必须按完整原字段验收

行业基准只使用正式基础层、已发布版本和合规本周候选，从周前正式锚点续算本周，并核验PIT、成分、公式、数值和输入哈希。不得读取quarantine或通过派生值夹带旧股息、旧财务修订

财务归档不得重算既有哈希或补写旧版本PIT元数据；港股基线步骤只读审计，不执行历史基线修复

## 发布与验收

两融逐股日频和市场汇总若因周末未披露而缺少本周日期，可作为 `margin_pending` 随周发布，不把缺失行填0、复制旧日或宣称全部维度完整。仍需采集一次并保留逐项回执、不可变来源快照、股票及日期缺口；已取得的两融行必须保持原字段与有效数值，异常值、范围污染、历史写入风险和两融资格错误仍阻断。其他数据域的完整性门禁不变

先在隔离候选视图上执行原生审计和本周逐交易日、逐字段验收，通过后才能发布追加版本。发布后必须再检查正式读取视图

唯一成功条件同时满足：

- `status=COMPLETE`
- `complete=true`
- `publication.status=PUBLISHED`
- `publication.formal_acceptance.passed=true`
- `formal_existing_files_rewritten=0`
- `historical_revisions_published=0`
- `historical_backfills_published=0`
- 插件外独立正式库验收为 `FORMAL_WEEK_ACCEPTED`，且逐项来源回执、公告请求窗口/分页、应有交易日及正式成员SHA均可复核

仅有 `PUBLISHED`、采集缓存、工作区成功或对话结束都不代表完成

推荐使用本Skill的 `scripts/run_weekly_end_to_end.py` 串接同周检查点续跑、独立正式库回读、全12 PIT父版本及最终版本、12模型就绪门禁、公共预检和空间审计。首次发起需显式传入目标周、已安装新版插件目录、上一周已批准release及其SHA、新的 `weekly_evidence` 子目录和 `PUBLISH_CURRENT_WEEK` 授权；执行中的退避只恢复失败项，不复用既往跨周或HTTP临时授权

独立程序 `/Users/bytedance/Documents/ChatGPT/量化交易/weekly_formal_acceptance.py` 不把 `COMPLETE` 或 `PUBLISHED` 当作充分证据。来源返回空窗但没有可信总数/分页或可核验来源证据时，保持“来源完整性不可证明”，不得宣称全部无遗漏；正式发布后验收失败只能报告“已发布但未通过正式验收”，不得改写、回滚或补造记录

`scripts/publish_all12_pit_release.py` 可直接从上一周已批准全12版本构建一个完整同周release，内部复用 `build_current_week_parent.py` 的全143输入闭包、旧前缀、SHA与新鲜度验收，并在发布前重新生成15只港股公告审计侧车；不再先发布完整父版本后重复要求新增同一批成员。已有合格版本直接复验，不得改写旧release

CSI300仅允许 `pit_source_lineage.py` 中有限的同一腾讯来源适配器标签兼容，保留全部旧操作、旧时点视图及记录数值，可用时间不变；新标签按经验证正式头信息的实际观测日生效，不回填到历史价格日期。仅认证revised vintage，base仍是原始元数据比较视图。其他字段、价格、来源或PIT差异继续阻断

整轮证据目录中的 `PIPELINE_BINDING.json` 固定目标周、上一版本SHA和安装目录，`pipeline.json` 记录当前阶段。再次手动调用时必须保持这些绑定，数据库COMPLETE直接进入下游；失败回执和门禁报告另存新文件，公共预检须明确固定同一个release/SHA/as_of/revised，不以进程退出或PUBLISHED替代通过

业绩日历公告证据用原公告ID与真实公告发布日期识别，不将会议日、财报期或可用日冒充事件日。新typed-v3契约不追溯重解释旧版本。SFC的historical_records须逐项检查，可得时间未知和旧位置日数据继续隔离，不新增长期豁免

空间审计使用新版插件的 `scripts/weekly_retention.py`，在独立验收、12/12就绪和公共预检全部通过后检查精确任务目录、引用关系及正式副本SHA，只删除真正冗余的临时文件；唯一来源快照、失败安全证据和仍被检查点引用的回执必须保留

清理器还须读取成功回执内引用的供应商快照；回执或其引用的临时证据缺失时拒绝清理。跨周桥接仍需使用的原始快照不得作为冗余文件删除

引用解析使用有去重的队列，并按归档路径、内嵌回执成员和SHA验证相对路径，不能相对当前工作目录猜测。无法证明冗余的文件保留并报告，不因此重新采集或重新发布数据库

最终报告必须包含目标日期、固定60只边界、各阶段cached/failed/timeout/empty/ineligible数量、fatal/warn、`freshness_complete`、`history_consistency_complete`、正式新增文件、隔离文件、既有文件改写数量、证据路径和已知不可消除缺口

历史一致性为false时必须如实报告。旧历史冲突即使经核验证明不影响本周，也只能作为未解决警告保留

## 当前明确失效的旧例外

- 2026-09-04专用IPv4环境和启动器不得用于其他周
- 2026-09-04的22项两融豁免不得扩展到其他日期
- 历次日期格式、价格口径、发布契约和行业基准代码修复授权均已使用完毕
- 2026-09-04旧检查点的 `BLOCKED_PUBLICATION` 不得由自动任务删除、重置或解锁
- `qwl_weekly_revalidate(resume=true)` 需要用户对具体检查点另行授权并提供原检查点SHA，自动任务不得调用
- qfq合同修复后的market恢复必须使用 `qwl_weekly_resume_market_safety` 绑定原检查点、原供应商快照和固定60只离线重放三个SHA；只能重置market为待采集，不能标成成功或直接发布，自动任务不得自行调用

## 预测与PIT读取衔接

数据库周更完成不自动修改模型或活动指针。用户在当前会话明确发起目标周数据库更新时，该主动指令同时允许在三类历史发布计数均为0后，为同一目标周追加一个全12模型PIT release；仅查询状态、监控或验收不构成新增release授权

后续预测、回测和优化必须使用项目批准的插件外PIT入口，逐决策日传入 `as_of` 并显式固定release和vintage，读取并报告 `known_exceptions` 与 `pit_diagnostics`

当前项目入口说明为 `/Users/bytedance/Documents/ChatGPT/量化交易/qwl_pit_gateway/README.md`。任何新周数据要进入预测入口，必须建立和验收新的PIT发布版本，不能直接读取工作缓存、quarantine或仅基础文件

### 全12模型PIT release固定步骤

1. 从当周 `publication.json` 和 `incremental_catalog.json` 读取已正式发布成员，要求 `status=PUBLISHED`、正式验收通过，且 `formal_existing_files_rewritten`、`historical_revisions_published`、`historical_backfills_published` 均为0
2. 使用 `scripts/publish_all12_pit_release.py` 构造12个登记模型143项输入的并集闭包，只纳入当前周incremental catalog中位于 `state/published_versions/<模型输入>/` 的正式成员，不读取quarantine
3. 候选release先在数据库外逐模型读取全部输入，并要求60份raw的最大日期均等于目标周最后交易日；任一失败时不得向数据库发布
4. 港股公告审计侧车必须从候选release精确固定的基础层和已发布版本层重新生成，逐段绑定原始查询窗口与每周发布窗口；不得复制上周侧车，也不得把发布周期冒充连续公告查询覆盖
5. 私有验收通过后仅以原子重命名新增一个release目录，不改写历史数据、旧release、Plugin、模型或活动指针；发布后复核所有既有文件元数据不变，新增文件必须全部位于该release目录
6. 运行项目 `/Users/bytedance/Documents/ChatGPT/量化交易/weekly_release_readiness_gate.py`，要求 `ALL_SELECTED_MODELS_READY`、12/12 ready、数据库只读不变
7. 再运行 `weekly_plugin_runner.cli preflight` 并显式传入新release目录和SHA，要求12只均为 `INPUT_DELIVERY_PASS`；仅通过发布范围门禁而公共preflight失败时不得安排研究员
8. 将新 `ENTRYPOINT.json`、release SHA、门禁和preflight证据作为当周研究员任务的固定输入，禁止退回registry旧默认release或旧插件原生数据库入口

如果同周已存在通过上述两级门禁的全12 release，直接复用，不重复发布。如果已存在的候选release只通过发布范围门禁但公共preflight失败，保持其不可变并报告失败；修复后必须取得用户对新增后继release的主动确认，不得改写原release

标准发布命令参数包括固定数据库、项目 `weekly_plugin_runner/registry.json`、当周已验收weekly run、父release、目标 `as_of`、新release id和 `PUBLISH_ALL12_PIT_CURRENT_WEEK` 授权令牌。该令牌只能由用户当前会话对同一目标周的主动更新指令提供，不能从旧周或仅状态查询继承

## 通知规则

手动执行期间在当前会话按阶段输出简短事实进度；完成、重要状态变化、安全失败、持久化等待或需要用户操作时立即说明

不得在进程仍运行时提前发送最终答复。若进入 `WAITING_SOURCE` 或 `WAITING_RETRY`，最终答复必须明确任务尚未完成、下一次允许重试时间，以及后续需要用户再次手动发起还是当前会话继续等待

## 20261031维护规则

周更主线、手动发起方式、周末写入窗口、退避预算和跨周授权不变，不创建定时任务

公告以明确的目标周一至周五为查询范围，逐日保存分页总数、响应SHA和固定60只过滤结果。可信零条与请求失败分开记录；完整日期经代码签名、池和归档SHA复核后复用，未完成日期重新分页核验，不拼接不同查询的半成品页面。批量隔离上限仍为1500秒，成功日期跨尝试恢复，不继承本周90分钟例外

缺失raw或明确qfq序列且历史同步完全未执行，或隔离父进程已记录归档SHA并证明超时结果未提升到工作缓存时，可进入仅采集恢复；回执、归档成员和固定60只缺失集合须一致。该恢复不授予发布资格，真实价格冲突、未来参考、来源或哈希漂移继续硬阻断；旧阻断检查点仍要求独立SHA授权，不自动迁移或解锁

A股周更私有进程可按腾讯、现有明确qfq备用、东方财富明确qfq、新浪明确qfq的顺序采集，原始请求与响应留证。来源数值不为贴合另一接口而乘除100；不支持的成交量单位只留拒绝证据并尝试下一个已批准来源，任何价格、因子或证据完整性失败继续阻断。新浪解析只允许JSON/字面量，不执行供应商文本，无未来股本或复权因子，本周行情和周前正式锚点仍须通过原生检查

成功缓存区分整条序列有效与本周及锚点有效；历史OHLC包含关系异常留在完整来源和警告中，不修正或发布旧行。本周缺日、锚点异常、非有限值、日期或证据漂移不得进入成功缓存

仅隔离处置新增一个窄类别：已有正式业务键的往年CNY年报资产负债表，来自eastmoney_hk_statements，原单位为基本货币单位，披露时间均为空，除五项既有金额及其CNY副本外元数据完全一致，差异全部符合百万元舍入且至少两项变化。候选保留undated，不确认其正确性，不补披露时间，旧正式值保留；候选和逐字段证明只进入隔离层及发布警告。其他无日期变化、本年报表、真实数值变化或有已知披露时间的修订不适用这条规则，仍按原门禁处理，不得扩大为任意历史冲突自动放行

PIT构建的跨周和同周分支都由CLI输出一次JSON。若仅输出丢失或非人工传输异常，先核验现有COMMIT、入口、清单及逐文件SHA、12模型输入闭包、目标周与weekly_run_id，合格后继续下游；禁止只凭退出码或目录存在判断成功。明确安全失败不能走产物恢复。数据库COMPLETE只跳过采集和数据库发布，已有PIT只复验不重复发布；12/12就绪和公共预检仍以同一release/SHA/as_of/revised只读验证

整轮成功输出overall_complete须同时绑定正式库验收、已提交PIT、12/12就绪、12/12公共预检和空间审计。all_domains_complete、freshness_complete、history_consistency_complete保留真实值，两融待补、历史口径和隔离候选不因流程完成而变为已补齐

清理仍在全部验收之后进行，只处理有精确恢复副本且无引用的临时文件。新增公告凭证与来源证明必须接入归档引用图；无安全删除候选时允许释放0字节，不删除唯一来源、隔离证据或失败安全证据
